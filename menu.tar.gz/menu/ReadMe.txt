
/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  ReadMe.txt                             */
/*  PRINCIPAL AUTHOR      :  LiYunpeng                              */
/*  SUBSYSTEM NAME        :  Menu                                   */
/*  MODULE NAME           :  Menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/20                             */
/*  DESCRIPTION           :  ReadMe of menu interface               */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by LiYunpeng,2014/09/20
 *
 */

MenuProgram:
    
    1) enter "help" to show all the command 
    2) enter "execute" to execute menu command
    3) enter "exit" to exit from execution
    4) enter "version" to show the menu version
    5) first time the program shows execution contains "help"/"execute"/"version"/"exit". 
    After delating the "execute" command ,program shows execution contains "help"/"version"
    and "exit".
